# VividFPSBoost (Fabric, Minecraft 1.21.11)

Scrolling the mouse wheel down acts as the attack/break button (client-side only).
Requires Fabric Loader and Fabric API.

Build: `./gradlew build` -> `build/libs/vividfpsboost-1.0.0.jar` (not the -sources jar).
Or push this repo to GitHub: Actions tab -> latest "build" run -> download "Artifacts".
