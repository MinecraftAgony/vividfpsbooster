package com.vividfpsboost;

import com.mojang.blaze3d.platform.InputConstants;
import com.vividfpsboost.mixin.KeyMappingAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

public class VividFPSBoostClient implements ClientModInitializer {
    // How many ticks the attack key stays "held" after a scroll tick.
    // 2 is enough to start breaking a block; repeated scrolling keeps it held.
    private static final int HOLD_TICKS = 2;
    private static int releaseIn = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (releaseIn > 0 && --releaseIn == 0) {
                KeyMapping.set(attackKey(mc), false);
            }
        });
    }

    private static InputConstants.Key attackKey(Minecraft mc) {
        return ((KeyMappingAccessor) mc.options.keyAttack).vividfpsboost$getKey();
    }

    public static void pressAttack(Minecraft mc) {
        InputConstants.Key key = attackKey(mc);
        KeyMapping.click(key);      // registers a click (attack / start breaking)
        KeyMapping.set(key, true);  // holds it so blocks keep breaking while you scroll
        releaseIn = HOLD_TICKS;
    }
}
