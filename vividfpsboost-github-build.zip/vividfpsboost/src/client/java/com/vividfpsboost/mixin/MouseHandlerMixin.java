package com.vividfpsboost.mixin;

import com.vividfpsboost.VividFPSBoostClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Shadow @Final private Minecraft minecraft;

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void vividfpsboost$onScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
        // Only in-world (no menu open) and only for scroll-down
        if (minecraft.screen == null && minecraft.player != null && yOffset < 0) {
            VividFPSBoostClient.pressAttack(minecraft);
            ci.cancel(); // stops the hotbar from changing
        }
    }
}
